// script.js
const hamburger = document.getElementById('hamburger');
const home = document.getElementById('home');

hamburger.addEventListener('click', () => {
    home.classList.toggle('active');
});